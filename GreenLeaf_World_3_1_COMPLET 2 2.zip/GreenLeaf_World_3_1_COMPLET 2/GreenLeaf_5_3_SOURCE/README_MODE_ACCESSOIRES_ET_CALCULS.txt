GREENLEAF 5.3 — AJOUT MODE & ACCESSOIRES ET CALCULATEUR

Contenu ajouté :
- Catégorie Mode & Accessoires dans index.html.
- Illustrations locales indicatives pour sacoches, casquette, bonnet, baskets, polos et T-shirts. Ce ne sont pas des photos certifiant un produit de marque.
- catalogue_mode_accessoires.csv : références de départ et prix publics repères connus ; les données inconnues sont laissées vides/à confirmer.
- GreenLeaf_Calculateur_Prix_Marges_Livraison.xlsx : variables de prix Espagne/France, coût d’achat réel, frais de voyage, marge cible et livraison variable.

RÈGLES
- Prix public Espagne et France : comparer uniquement la même référence, le même format et la même variante.
- Si l’Espagne est moins chère : référence comparative = moyenne Espagne/France. Le prix de vente GreenLeaf doit aussi couvrir le coût d’achat réel, les frais de trajet affectés et la marge cible. Si le prix devient supérieur au repère France, marquer le produit non compétitif.
- Sinon : coût d’achat réel + frais d’approvisionnement affectés + marge cible de 1,50 € (petit lot) ou 2 € (lot important).
- Frais de trajet : 250 € répartis au prorata sur un budget d’achats de référence de 3 500 €, modifiable entre 3 000 et 4 000 €.
- Livraison : coût véhicule paramétré à 0,35 €/km aller-retour, frais divers 3 €, bénéfice cible de tournée 20 €, seuil indicatif de panier individuel 250 €. Les tarifs facturés selon distance/panier dans l’onglet sont des hypothèses modifiables, pas une grille finale confirmée.

IMPORTANT
Les prix cités dans le catalogue sont des prix publics de référence provenant des échanges précédents, pas des tarifs fournisseurs garantis. Le coût d’achat réel doit être saisi avant que le prix de vente soit considéré comme calculé. Les formules ne valident pas automatiquement l’intérêt commercial.
Aucune modification n’a été appliquée à Netlify ou Supabase. Sauvegarder avant de déployer.
