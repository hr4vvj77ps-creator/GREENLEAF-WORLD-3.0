# GreenLeaf World 3.0 — interface unifiée (prototype local)

Cette version reprend la référence visuelle `assets/interface-reference-user.jpeg` et reconstruit l'interface en véritables composants HTML/CSS/JavaScript. L'image de référence n'est plus utilisée comme une capture plein écran avec des zones cliquables invisibles : la navigation est rendue par de vrais boutons et chaque rubrique possède une page dédiée.

## Ouvrir
1. Décompresser l'archive.
2. Ouvrir `GreenLeaf_World_3_0/index.html` dans un navigateur récent.
3. La démo fonctionne localement sans installation et sauvegarde la progression de test dans le stockage local du navigateur.

## Rubriques intégrées
- Accueil / tableau de bord avec dernières activités, événements et actualités de démonstration.
- Monde classique et page d'accès protégée du Monde de la Nuit.
- Mon aventure, inventaire, refuge évolutif, montures, compagnons, quêtes, carte au trésor.
- Boutiques/catalogues de démonstration, panier, commandes locales et livraison (écrans de conception).
- Producteurs/artisans (emplacements à compléter après vérification), réseau/parrainage, premières récompenses, profil, illustrations et paramètres.
- Soldes distincts de démonstration : crédit GreenLeaf, Mémonet, K de lune, or, argent, XP, réputation et rang réseau.

## Images
Les trois images existantes sont conservées dans `assets/` et présentées dans la page « Illustrations » comme propositions visuelles. Elles ne sont pas injectées automatiquement dans les pages de l'interface : elles restent à valider comme visuels de page avant intégration. La référence d'interface reste accessible dans le dossier et sert de guide de reconstruction.

## Limites importantes
- Cette version est un prototype local. Les activités et les événements sont mis à jour à partir des actions locales de démonstration, pas depuis un flux externe en direct.
- Aucun compte réel, droit serveur, achat, paiement, commande fournisseur, GPS ou livraison réelle n'est activé par ce prototype.
- La permission réelle du Monde de la Nuit doit être vérifiée côté serveur (Supabase/RLS). L'écran est volontairement verrouillé.
- Les prix du mini-catalogue sont fictifs et uniquement destinés à tester le panier. Ne pas les utiliser comme prix commerciaux.
- Le dossier `GreenLeaf_5_3_SOURCE` et `ARCHIVE_ORIGINALE_GREENLEAF_5_3_AUTH_PIN.zip` sont conservés sans remplacement. Ne pas déployer ce prototype à la place de la version GreenLeaf 5.3 connectée.
- Ne jamais exposer de clé Supabase `service_role` dans un site public.

## Structure
- `index.html`, `styles.css`, `app.js` : interface World 3.0 unifiée.
- `assets/` : références visuelles existantes, proposées dans la page Illustrations.
- `docs/` : cahier des charges, état des fonctions et notes de conception conservées.
- `../GreenLeaf_5_3_SOURCE/` : source existante GreenLeaf 5.3, migrations, images et documentation.
- `../ARCHIVE_ORIGINALE_GREENLEAF_5_3_AUTH_PIN.zip` : archive d'origine conservée.
