-- GreenLeaf 5.0 : fonction de lecture du statut d'accès Fantômes
-- À exécuter une seule fois dans Supabase > SQL Editor.
create or replace function public.can_current_user_access_ghosts()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from private.ghost_access ga
    where ga.user_id = (select auth.uid())
      and ga.allowed = true
  );
$$;

revoke all on function public.can_current_user_access_ghosts() from public, anon;
grant execute on function public.can_current_user_access_ghosts() to authenticated;
