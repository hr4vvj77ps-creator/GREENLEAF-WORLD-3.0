GREENLEAF 5.3 — vérification et migration Fantômes

CE QUI A ÉTÉ VÉRIFIÉ
- L’archive source s’ouvre et son contenu ZIP n’est pas endommagé.
- Les deux blocs JavaScript présents dans index.html passent le contrôle syntaxique Node.js.
- La version de l’interface contenue dans cette archive est basée sur la démo connectée 5.0 fournie.
- La migration Fantômes 5.3 est ajoutée séparément, avec les catégories Tazmania, Love, Black and White, Ski et Champignons, les champs de visibilité et de chemin d’image, et les règles RLS.

À FAIRE DANS SUPABASE
1. Ouvrir Supabase > SQL Editor.
2. Si la migration de base n’a pas encore été exécutée, lancer MIGRATION_SUPABASE.sql une seule fois.
3. Vérifier que les fonctions private.is_admin() et private.can_access_ghosts() et la table public.ghost_items existent.
4. Ouvrir MIGRATION_FANTOMES_5_3.sql, copier tout le contenu et l’exécuter en une fois.
5. Si une erreur apparaît, ne pas exécuter des lignes au hasard : copier le message complet et me l’envoyer.
6. Vérifier ensuite les catégories dans Table Editor > public.ghost_categories.

IMPORTANT
- Je n’ai pas accès à ton projet Supabase réel pour exécuter ce SQL : il est donc préparé mais pas encore validé sur ta base.
- La migration ajoute les catégories et les règles de base de données ; elle ne crée pas encore une interface administrateur complète pour modifier les catégories, ajouter des images et gérer les autorisations depuis le site.
- image_path est seulement un champ de référence : il ne crée pas de stockage d’images. Pour héberger des images, il faudra configurer un bucket Storage et ses règles.
- Le compte admin doit déjà avoir le rôle admin dans private.user_roles.
- Ne mets jamais de clé service_role/secret dans index.html. La clé publishable peut être utilisée côté navigateur avec des politiques RLS correctes.
- Le panier et la messagerie de démonstration peuvent rester locaux au navigateur.
