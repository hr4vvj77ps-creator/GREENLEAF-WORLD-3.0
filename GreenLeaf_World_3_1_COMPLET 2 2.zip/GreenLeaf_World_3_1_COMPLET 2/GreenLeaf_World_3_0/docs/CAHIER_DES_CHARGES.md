# Cahier des charges — GreenLeaf World 3.0

## Principes généraux
1. Conserver l’application GreenLeaf 5.3 actuelle comme base à auditer, ne pas l’écraser.
2. Ne déclarer aucune fonction terminée sans tester les cas normaux, les erreurs, les doublons, les permissions et la persistance.
3. Une maquette visuelle n’équivaut pas à une fonction connectée.
4. Ne jamais inventer de prix, stock, fournisseur, avis ou état de paiement.

## Deux univers séparés
### Monde classique
- Carte fantastique, exploration, personnages, refuge persistant, avant-postes, quêtes, guildes et tavernes.
- Compagnons, montures, collecte, artisanat, fragments de cartes et coffres obtenus par progression.
- Royaumes envisagés : forêt ancienne, terres enchantées, Sept Mers, Royaume du Ciel, royaumes oubliés, grottes de cristal, cité engloutie, royaume lunaire secret, désert des dragons et marais des sorcières.
- Les récompenses commerciales éventuelles doivent être transparentes et juridiquement validées ; pas de hasard payant requis pour jouer.

### Monde de la Nuit
- Invisible depuis la carte classique pour un compte non autorisé.
- Personnage, carte, inventaire, points, catalogue, panier, commandes et historique propres.
- Contrôle serveur/Supabase RLS. Révoquer l’accès bloque l’entrée mais ne supprime pas les données historiques.
- Le mode local du prototype n’est pas une sécurité réelle.

## Catalogue et prix
- Catégories courantes : bonbons, vêtements, produits du quotidien, alimentation espagnole, accessoires, parfums.
- Ajouter uniquement des produits dont la référence et les prix Espagne/France sont vérifiés.
- Bénéfice cible GreenLeaf : 1,50 € par article en petite quantité ; 2,00 € en quantité plus importante, si possible.
- Ne pas inventer les prix ; utiliser « à confirmer » lorsque les informations manquent.
- Présenter clairement format, prix d’achat, prix de vente, bénéfice brut, prix/kg et source/date de vérification.
- Promotions alimentation espagnole envisagées : 50 € -5 %, 80 € -10 %, 120 € -15 %, 230 € -20 %.
- Fromages Artesans dels Avalls : conserver uniquement les références réelles, disponibles et tarifées.
- Parfums : parfum classique à porter sur la peau ; cible évoquée de 35–38 € lorsque la référence réelle le justifie, sous 50 €, lot de cinq avec -20 % envisagé. Tous ces prix restent à vérifier.
- Les catégories spéciales doivent garder leurs règles distinctes. Vérifier les obligations légales avant d’activer une catégorie réglementée.

## Producteurs, réseau et parrainage
- Espace réel : profil vérifié, catalogue, formats, prix, stock, commandes et logistique.
- Espace fantastique : ferme, verger, atelier, fromagerie ou échoppe virtuelle.
- Autoriser les ventes directes producteurs-clients. Pas de commission implicite : toute rémunération GreenLeaf doit être transparente et acceptée.
- Distinguer XP personnelle, réputation professionnelle et progression globale.
- Attribuer la progression réseau pour des contributions vérifiées ; prévoir plafonds, rendements décroissants, contrôles anti-fraude et bonus de diversité territoriale.

## Commandes et livraison
- Paniers classique et nocturne distincts ; aucun mélange de produits ou d’historiques.
- Pour les produits non standard, prévoir une messagerie intégrée avec possibilité d’envoyer le panier dans le message.
- Suivi de statut par commande et par colis.
- Code de remise livreur → hôte de relais distinct du code de retrait hôte → destinataire.
- Les remises partielles ne ferment que les colis concernés.
- Journal d’audit : qui a remis/reçu, quand, quel colis, quel statut.
- Limite de conception retenue : 30 km maximum à l’aller entre chaque client et le point de rendez-vous. Les créneaux horaires doivent être confirmés avec les besoins actuels avant implémentation.
- Partage de localisation volontaire, limité au besoin et à la durée utile.

## Paiements et finances
- Pas de collecte de données de carte dans l’application elle-même ; utiliser un prestataire autorisé et documenter le flux.
- Distinguer prix de vente, marge brute, frais de paiement, frais de livraison, remboursements et revenus éventuels de réseau.
- Crypto du Monde de la Nuit : paiement à la livraison envisagé ; prix de référence en euros ; vendeur choisit l’actif/réseau de réception ; client choisit l’actif/réseau de paiement ; conversion seulement via route vérifiée ; frais et taux visibles ; QR unique par commande ; transaction vérifiée indépendamment avant statut payé.
- Ne jamais marquer payé sur la seule base d’un QR ou d’une capture d’écran.
- USDC/EURC/USDT : options à examiner, non décisions finales.
- Valider le droit applicable (MiCA, services de paiement, KYC/AML le cas échéant, fiscalité, consommateurs, produits et règles françaises/UE) avant toute mise en production.
- Préférer l’absence de garde centralisée par GreenLeaf si cela est viable et juridiquement validé.
- Points de jeu séparés de l’argent, sans conversion automatique.

## Authentification et sécurité
- Préserver le flux pseudo/PIN existant, ajouter email + mot de passe si confirmé comme exigence de la version réelle, biométrie ultérieure via mécanisme sécurisé de l’appareil.
- Rôles envisagés : client, livreur, modérateur, administrateur/gérant.
- Contrôles côté serveur et politiques RLS. Pas de secret `service_role` dans le navigateur.
- Journaux d’audit, sauvegardes, environnement de test, plan de retour arrière.
- Toute migration SQL est préparée après inspection, sauvegarde et vérification de compatibilité.

## Étapes de livraison
1. Audit du dépôt et sauvegarde.
2. Inventaire des fonctions et données existantes.
3. Schéma de données et permissions.
4. Catalogue et calculs, sans prix inventés.
5. Paniers, messagerie et commandes.
6. Producteurs, réseau et livraison.
7. Monde de la Nuit et séparation des données.
8. Authentification et sécurité.
9. Paiements seulement après validation juridique et choix du prestataire.
10. Tests, staging, vérification puis déploiement contrôlé.
