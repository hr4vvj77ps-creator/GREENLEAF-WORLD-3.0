
/**
 * GREENLEAF — Gestion des distances des points de rendez-vous
 * Règle : 30 km maximum à l'aller par client.
 *
 * Ce module vérifie les distances fournies par le calculateur
 * d'itinéraires. Il ne calcule pas lui-même les routes.
 */

export const DISTANCE_MAX_RENDEZ_VOUS_KM = 30;

/**
 * Vérifie la distance d'un client vers un point de rendez-vous.
 *
 * @param {number} distanceKm Distance routière à l'aller, en km.
 */
export function verifierDistanceClient(distanceKm) {
  if (
    typeof distanceKm !== "number" ||
    !Number.isFinite(distanceKm) ||
    distanceKm < 0
  ) {
    throw new Error(
      "La distance doit être un nombre positif ou nul."
    );
  }

  const distance = Math.round(distanceKm * 10) / 10;
  const autorise = distanceKm <= DISTANCE_MAX_RENDEZ_VOUS_KM;

  return {
    autorise,
    distanceKm: distance,
    limiteKm: DISTANCE_MAX_RENDEZ_VOUS_KM,
    message: autorise
      ? `Distance acceptée : ${distance} km à l'aller.`
      : `Distance trop élevée : ${distance} km. Maximum autorisé : 30 km à l'aller.`
  };
}

/**
 * Vérifie que TOUS les clients d'une tournée respectent la limite.
 *
 * Format attendu :
 * [
 *   { clientId: "client-1", distanceKm: 12 },
 *   { clientId: "client-2", distanceKm: 25 }
 * ]
 */
export function verifierTourneeRendezVous(clients) {
  if (!Array.isArray(clients) || clients.length === 0) {
    throw new Error(
      "La tournée doit contenir au moins un client."
    );
  }

  const resultats = clients.map((client) => {
    if (
      !client ||
      typeof client.clientId !== "string" ||
      client.clientId.trim() === ""
    ) {
      throw new Error(
        "Chaque client doit avoir un identifiant non vide."
      );
    }

    const verification = verifierDistanceClient(client.distanceKm);

    return {
      clientId: client.clientId,
      distanceKm: verification.distanceKm,
      autorise: verification.autorise,
      message: verification.message
    };
  });

  const clientsHorsLimite = resultats.filter(
    (client) => !client.autorise
  );

  const tourneeValide = clientsHorsLimite.length === 0;

  return {
    tourneeValide,
    limiteKm: DISTANCE_MAX_RENDEZ_VOUS_KM,
    clients: resultats,
    clientsHorsLimite,
    action: tourneeValide
      ? "VERIFIER_RENTABILITE"
      : "RECHERCHER_AUTRE_POINT_OU_SEPARER_TOURNEE",
    message: tourneeValide
      ? "Tous les clients sont à 30 km maximum à l'aller. Vérifier la rentabilité avant confirmation."
      : `${clientsHorsLimite.length} client(s) dépassent 30 km. Chercher un autre point ou séparer la tournée.`
  };
}
