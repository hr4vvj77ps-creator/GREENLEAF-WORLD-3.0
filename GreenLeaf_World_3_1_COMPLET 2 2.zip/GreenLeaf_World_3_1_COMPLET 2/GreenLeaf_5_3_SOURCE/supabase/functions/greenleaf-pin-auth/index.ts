import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { createHmac } from "node:crypto";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS", "Content-Type": "application/json" };
const json = (body: unknown, status=200) => new Response(JSON.stringify(body), { status, headers: cors });
const url = Deno.env.get("SUPABASE_URL")!;
const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
const pepper = Deno.env.get("GREENLEAF_PIN_PEPPER");
const admin = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
const publicAuth = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
const normalize = (s: string) => s.trim().toLowerCase();
const syntheticEmail = (username: string) => `${normalize(username)}@accounts.greenleaf.invalid`;
function internalPassword(username: string, pin: string) {
  if (!pepper || pepper.length < 32) throw new Error("GREENLEAF_PIN_PEPPER doit contenir au moins 32 caractères.");
  return createHmac("sha256", pepper).update(`${normalize(username)}:${pin}`).digest("hex") + "G!9x";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ ok:false, message:"Méthode non autorisée." },405);
  try {
    const body = await req.json();
    const action = body?.action;
    const username = String(body?.username ?? "").trim();
    const pin = String(body?.pin ?? "");
    if (!/^[a-zA-Z0-9_.-]{3,24}$/.test(username) || !/^\d{6}$/.test(pin)) return json({ok:false,message:"Pseudo invalide ou PIN de 6 chiffres requis."},400);
    const key = `user:${normalize(username)}`;
    const { data: attempt } = await admin.from("gl_pin_attempts").select("failed_count,blocked_until").eq("attempt_key",key).maybeSingle();
    if (attempt?.blocked_until && new Date(attempt.blocked_until).getTime() > Date.now()) return json({ok:false,message:"Trop de tentatives. Réessaie plus tard."},429);
    if (action === "signup") {
      const email = syntheticEmail(username);
      const password = internalPassword(username,pin);
      const { data: created, error: createError } = await admin.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { username } });
      if (createError) return json({ok:false,message:createError.message.includes("already") ? "Ce pseudo est déjà utilisé." : "Création impossible. Vérifie le pseudo ou contacte l’administrateur."},400);
      const { error: profileError } = await admin.from("gl_profiles").insert({user_id:created.user.id, username, role:"client", approved:false});
      if (profileError) { await admin.auth.admin.deleteUser(created.user.id); return json({ok:false,message:"Profil non créé. Vérifie la migration SQL."},500); }
      await admin.from("gl_pin_attempts").upsert({attempt_key:key,failed_count:0,blocked_until:null,updated_at:new Date().toISOString()});
      return json({ok:true,message:"Compte créé. Il reste en attente d’autorisation par l’administrateur. Connecte-toi une fois l’accès autorisé."});
    }
    if (action === "login") {
      const email = syntheticEmail(username);
      const password = internalPassword(username,pin);
      const {data,error} = await publicAuth.auth.signInWithPassword({email,password});
      if (error || !data.session) {
        const count = (attempt?.failed_count ?? 0) + 1;
        const blocked = count >= 5 ? new Date(Date.now()+15*60*1000).toISOString() : null;
        await admin.from("gl_pin_attempts").upsert({attempt_key:key,failed_count:blocked?0:count,blocked_until:blocked,updated_at:new Date().toISOString()});
        return json({ok:false,message:blocked ? "Trop de tentatives. Compte temporairement bloqué 15 minutes." : "Pseudo ou PIN incorrect."},401);
      }
      await admin.from("gl_pin_attempts").upsert({attempt_key:key,failed_count:0,blocked_until:null,updated_at:new Date().toISOString()});
      const {data:profile} = await admin.from("gl_profiles").select("approved,role,username").eq("user_id",data.user.id).maybeSingle();
      if (!profile) { await publicAuth.auth.signOut(); return json({ok:false,message:"Profil introuvable. Contacte l’administrateur."},403); }
      return json({ok:true,message:profile.approved || profile.role === "admin" ? `Connexion réussie, ${profile.username}.` : "Connexion réussie, mais ton compte est en attente d’autorisation pour les espaces protégés.", session:data.session, profile:{username:profile.username,role:profile.role,approved:profile.approved}});
    }
    return json({ok:false,message:"Action inconnue."},400);
  } catch (e) {
    console.error("greenleaf-pin-auth failure", e);
    return json({ok:false,message:"Erreur serveur. Vérifie les secrets et les migrations."},500);
  }
});
