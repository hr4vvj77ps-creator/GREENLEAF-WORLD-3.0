GREENLEAF 5.3 — PACK CONNEXION E-MAIL + PSEUDO/PIN + VISUAL ID

CE QUI A ÉTÉ AJOUTÉ
- index.html : connexion e-mail/mot de passe avec Supabase Auth.
- Inscription e-mail avec mot de passe (minimum 8 caractères côté interface).
- Demande de réinitialisation du mot de passe par e-mail.
- Champ pseudo facultatif à l'inscription e-mail ; s'il est vide ou invalide, le SQL crée un pseudo technique GreenLeaf.
- Conservation du formulaire pseudo + PIN à 6 chiffres et de l'Edge Function greenleaf-pin-auth.
- Carte Visual ID GreenLeaf dérivée de l'identifiant Supabase de la session ; elle est visuelle et ne remplace pas l'authentification.
- Bouton biométrie qui vérifie seulement si WebAuthn semble pris en charge. Il n'enregistre pas de passkey et n'authentifie pas par empreinte/Face ID.
- MIGRATION_EMAIL_AUTH_PROFILE.sql : crée un profil client non approuvé pour les nouveaux comptes e-mail.

COMPTE ADMINISTRATEUR ET DONNÉES
- Aucun mot de passe personnel n'est modifié par ce ZIP.
- Aucun compte existant n'est supprimé ni migré automatiquement.
- Aucun SQL n'est exécuté automatiquement.
- Les nouveaux comptes sont créés avec role=client et approved=false ; l'administrateur doit les autoriser selon les règles GreenLeaf.

MISE EN PLACE
1. Décompresse ce dossier et garde l'ancien dossier en sauvegarde.
2. Dans Supabase > SQL Editor, exécute MIGRATION_EMAIL_AUTH_PROFILE.sql une seule fois. Elle ajoute un trigger pour les nouvelles inscriptions ; elle ne modifie pas les profils déjà présents.
3. Dans Supabase > Authentication > URL Configuration, vérifie Site URL et Redirect URLs pour ton URL Netlify afin que confirmation et réinitialisation e-mail reviennent sur le site.
4. Vérifie dans Supabase > Authentication > Providers que Email est activé et règle la confirmation e-mail selon ton choix.
5. Déploie le contenu du dossier sur Netlify.
6. La connexion PIN continue d'utiliser l'Edge Function greenleaf-pin-auth. Elle doit déjà être déployée et ses secrets serveur configurés.
7. Teste d'abord avec un compte de test, pas avec le compte administrateur.

LIMITES IMPORTANTES
- La connexion e-mail crée une session Supabase Auth. Le profil associé reste non approuvé par défaut.
- Le login pseudo + PIN est conservé selon l'implémentation déjà présente. Le compte administrateur existant lié à une adresse e-mail personnelle n'est pas migré automatiquement vers un compte technique de pseudo/PIN ; le login e-mail reste disponible pour lui.
- Le Visual ID affiché est une représentation visuelle de l'UUID Supabase, pas un secret.
- Face ID / Touch ID/empreinte n'est PAS activé. Pour l'activer réellement, il faudra ajouter WebAuthn/passkeys avec génération et vérification des challenges côté serveur et stockage sécurisé des credentials.
- Le panier et la messagerie restent une démo locale dans ce projet ; cette modification ne les rend pas multi-appareils.
- Ne place jamais SUPABASE_SERVICE_ROLE_KEY ni GREENLEAF_PIN_PEPPER dans index.html.

Cette archive a été modifiée et contrôlée statiquement. Elle n'a pas été déployée ni testée contre le projet Supabase/Netlify réel depuis ici.
