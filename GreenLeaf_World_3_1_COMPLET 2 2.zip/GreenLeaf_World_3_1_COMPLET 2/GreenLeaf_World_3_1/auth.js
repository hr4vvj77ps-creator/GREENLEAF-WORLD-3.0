(() => {
  "use strict";
  const SUPABASE_URL = "https://dcqqtigsqpkzifkuudeu.supabase.co";
  const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_Fzje0u1twEccJUVvK8hb2w_X4BTPJ3d";
  const SESSION_KEY = "greenleaf_world_session";
  const gate = document.getElementById("glAuthGate");
  const form = document.getElementById("glAuthForm");
  const message = document.getElementById("glAuthMessage");
  const submit = document.getElementById("glAuthSubmit");
  const pin = document.getElementById("glAuthPin");

  document.body.classList.add("gl-auth-locked");
  document.body.classList.remove("gl-auth-ready");

  function say(text) { message.textContent = text; }
  function getSession() {
    try { return JSON.parse(sessionStorage.getItem(SESSION_KEY) || "null"); }
    catch { return null; }
  }
  function clearSession() { sessionStorage.removeItem(SESSION_KEY); }
  function unlock(profile) {
    window.GreenLeafAuthProfile = profile;
    gate.hidden = true;
    document.body.classList.remove("gl-auth-locked");
    document.body.classList.add("gl-auth-ready");
    const name = document.getElementById("displayName");
    if (name) name.textContent = profile.username;
    document.querySelectorAll(".gl-profile-username").forEach(el => {
      el.textContent = profile.username;
    });
    const pill = document.querySelector(".demo-pill");
    if (pill) pill.textContent = "Connecté · " + profile.username;
  }
  async function validateSession(session) {
  if (!session || !session.access_token) return false;
  try {
    const response = await fetch(
      SUPABASE_URL + "/functions/v1/greenleaf-pin-auth-",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: SUPABASE_PUBLISHABLE_KEY,
          Authorization: "Bearer " + session.access_token
        },
        body: JSON.stringify({ action: "validate_session" })
      }
    );
    let result;
    try { result = await response.json(); }
    catch { return false; }

    if (!response.ok || !result.ok || !result.profile) return false;
    if (!result.profile.approved && result.profile.role !== "admin") return false;
    return result.profile;
  } catch {
    return false;
  }
}

form.addEventListener("submit", async event => {
    event.preventDefault();
    const username = document.getElementById("glAuthUsername").value.trim();
    const pinValue = pin.value;
    if (!/^[A-Za-z0-9_.-]{3,24}$/.test(username) || !/^\d{6}$/.test(pinValue)) {
      say("Vérifie ton pseudo et ton PIN à 6 chiffres.");
      return;
    }
    submit.disabled = true;
    say("Vérification de la connexion…");
    try {
      const response = await fetch(SUPABASE_URL + "/functions/v1/greenleaf-pin-auth-", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: SUPABASE_PUBLISHABLE_KEY
        },
        body: JSON.stringify({ action: "login", username, pin: pinValue })
      });
      let result;
      try { result = await response.json(); }
      catch { throw new Error("Réponse serveur illisible. La fonction PIN est peut-être indisponible."); }

      if (!response.ok || !result.ok) {
        throw new Error(result.message || "Connexion refusée.");
      }
      if (!result.profile || (!result.profile.approved && result.profile.role !== "admin")) {
        clearSession();
        say("Ton compte est en attente d’autorisation par l’administrateur. L’application reste verrouillée.");
        pin.value = "";
        return;
      }
      if (!result.session || !result.session.access_token) {
        throw new Error("Le serveur n’a pas fourni de session valide.");
      }
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(result.session));
      unlock(result.profile);
    } catch (error) {
      say(error instanceof TypeError
        ? "Connexion impossible au serveur. Vérifie le réseau et le déploiement de la fonction PIN."
        : (error.message || "Erreur de connexion."));
    } finally {
      submit.disabled = false;
    }
  });

  const accountButton = document.getElementById("accountBtn") || document.querySelector('[data-act="quit"]');
  if (accountButton) accountButton.addEventListener("click", event => {
    event.preventDefault();
    event.stopImmediatePropagation();
    clearSession();
    window.location.reload();
  }, true);

  // La session est restaurée uniquement après validation côté serveur.
(async () => {
  const session = getSession();
  if (!session) {
    gate.hidden = false;
    return;
  }

  const profile = await validateSession(session);
  if (!profile) {
    clearSession();
    gate.hidden = false;
    say("Session expirée ou vérification impossible. Reconnecte-toi.");
    return;
  }
  unlock(profile);
})();
})();