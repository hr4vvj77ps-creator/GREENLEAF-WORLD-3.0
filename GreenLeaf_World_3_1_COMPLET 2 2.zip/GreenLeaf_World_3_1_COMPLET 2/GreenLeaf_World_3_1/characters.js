 /* GreenLeaf World — module personnages
Module additionnel : ne remplace pas app.js ni auth.js. */
(function () {
"use strict";
const MAX_LEVEL = 50;
const STORAGE_PREFIX = "greenleaf_characters_v1_";

const fantasy = [
['f_01', 'Aeloria', 'Lumière', 'Arc Stellaire'],
['f_02', 'Thorgar', 'Terre', 'Marteau des Titans'],
['f_03', 'Kaelen', 'Vent', 'Lames Zéphyr'],
['f_04', 'Lyra', 'Eau', 'Sceptre des Cascades'],
['f_05', 'Ignis', 'Feu', 'Dague Solaire'],
['f_06', 'Sylas', 'Nature', 'Bâton Sylvestre'],
['f_07', 'Valeria', 'Foudre', 'Lance Électrique'],
['f_08', 'Orion', 'Arcane', 'Grimoire Ancien'],
['f_09', 'Balthazar', 'Métal', 'Épée de Mithril'],
['f_10', 'Elowen', 'Glace', 'Rapière de Cristal'],
['f_11', 'Garrick', 'Terre', 'Hache de Guerre Runique'],
['f_12', 'Selene', 'Lune', 'Chakram Stellaire'],
['f_13', 'Darius', 'Feu', 'Espadon Volcanique'],
['f_14', 'Faelar', 'Vent', 'Arc Long des Elfes'],
['f_15', 'Nalia', 'Eau', 'Fouet Aquatique'],
['f_16', 'Brom', 'Métal', 'Marteau de Siège'],
['f_17', 'Talia', 'Nature', 'Liane Épineuse'],
['f_18', 'Zephyr', 'Foudre', 'Gantelets Tempestueux'],
['f_19', 'Morwenna', 'Arcane', 'Orbe Temporel'],
['f_20', 'Cassian', 'Lumière', 'Bouclier Sacré'],
['f_50', 'Aurelius', 'Lumière', 'Épée des Rois']
];

const night = [
['n_01', 'Vespera', 'Ombre', 'Lame de Cendres'],
['n_02', 'Morgath', 'Magma', 'Marteau des Abysses'],
['n_03', 'Malakor', 'Néant', 'Faux des Âmes'],
['n_04', 'Azazel', 'Feu Noir', 'Trident Infernal'],
['n_05', 'Lilith', 'Sang', 'Griffes Hémales'],
['n_06', 'Nyx', 'Ténèbres', 'Dagues Nocturnes'],
['n_07', 'Gorok', 'Poison', 'Cimeterre Corrompu'],
['n_08', 'Xylia', 'Glace Noire', 'Épée de Givre Mortel'],
['n_09', 'Belial', 'Chaos', 'Fléau des Damnés'],
['n_10', 'Mephisto', 'Âme', 'Sceptre des Supplices'],
['n_11', 'Vorgoth', 'Cendre', 'Massue de Purgatoire'],
['n_12', 'Hecate', 'Magie Noire', 'Grimoire Maudit'],
['n_13', 'Stryker', 'Foudre Noire', 'Lame Voltaïque Sombre'],
['n_14', 'Valkor', 'Abysse', 'Hache des Profondeurs'],
['n_15', 'Zarox', 'Corruption', 'Arbalète Pestilentielle'],
['n_16', 'Morana', 'Nécro', 'Faux Funèbre'],
['n_17', 'Kuro', 'Ombre', 'Katana des Ombres'],
['n_18', 'Malphas', 'Chaos', 'Griffes Démoniaques'],
['n_19', 'Astaroth', 'Feu Noir', 'Épée du Péché'],
['n_20', 'Baal', 'Ténèbres', 'Trident des Abysses'],
['n_50', 'Lucifer', 'Néant Suprême', 'Épée du Déchu']
];

const known = fantasy.map(function (c) {
return { id: c[0], name: c[1], world: 'classique', element: c[2], weapon: c[3] };
}).concat(night.map(function (c) {
return { id: c[0], name: c[1], world: 'nuit', element: c[2], weapon: c[3] };
}));

const characters = [];
for (let i = 1; i <= 50; i += 1) {
const id = String(i).padStart(2, '0');
const f = known.find(function (c) { return c.id === 'f_' + id; });
const n = known.find(function (c) { return c.id === 'n_' + id; });

characters.push(f || {
  id: 'f_' + id,
  name: 'Héros classique ' + id,
  world: 'classique',
  element: 'À définir',
  weapon: 'À définir',
  provisional: true
});
characters.push(n || {
  id: 'n_' + id,
  name: 'Héros nocturne ' + id,
  world: 'nuit',
  element: 'À définir',
  weapon: 'À définir',
  provisional: true
});

}

function accountKey() {
const profile = window.GreenLeafAuthProfile;
if (!profile) return null;
const id = profile.id || profile.user_id || profile.username || profile.pseudo;
if (!id) return null;
return STORAGE_PREFIX + String(id).toLowerCase();
}

function emptySave() {
return { activeId: null, collection: {}, updatedAt: new Date().toISOString() };
}

function load() {
const key = accountKey();
if (!key) return { save: emptySave(), persistent: false };
try {
const raw = localStorage.getItem(key);
return {
save: raw ? JSON.parse(raw) : emptySave(),
persistent: false
};
} catch (error) {
return { save: emptySave(), persistent: false };
}
}

function store(save) {
const key = accountKey();
if (!key) throw new Error('Connexion requise.');
save.updatedAt = new Date().toISOString();
localStorage.setItem(key, JSON.stringify(save));
}

function xpForNext(level) {
return level >= MAX_LEVEL ? 0 : level * 100;
}

function createProgress(id) {
return {
characterId: id,
level: 1,
xp: 0,
totalXp: 0,
stats: { force: 10, defense: 10, agility: 10, magic: 10 },
skills: [],
createdAt: new Date().toISOString()
};
}

function gainXp(progress, amount) {
if (!Number.isFinite(amount) || amount <= 0) {
throw new Error("Le gain d'expérience doit être positif.");}
progress.totalXp += Math.floor(amount);
progress.xp += Math.floor(amount);
while (progress.level < MAX_LEVEL &&
progress.xp >= xpForNext(progress.level)) {
progress.xp -= xpForNext(progress.level);
progress.level += 1;
progress.stats.force += 2;
progress.stats.defense += 2;
progress.stats.agility += 1;
progress.stats.magic += 2;
}
if (progress.level === MAX_LEVEL) progress.xp = 0;
return progress;
}

function choose(id) {
if (!accountKey()) throw new Error('Connecte-toi pour choisir un personnage.');
const character = characters.find(function (c) { return c.id === id; });
if (!character) throw new Error('Personnage inconnu.');
const result = load();
const save = result.save;
if (!save.collection[id]) save.collection[id] = createProgress(id);
save.activeId = id;
store(save);
return save;
}

function awardXp(amount) {
const result = load();
const save = result.save;
if (!accountKey()) throw new Error('Connecte-toi pour progresser.');
if (!save.activeId || !save.collection[save.activeId]) {
throw new Error("Choisis d'abord un personnage.");}
gainXp(save.collection[save.activeId], amount);
store(save);
return save;
}

function escapeHtml(value) {
return String(value).replace(/[&<>"']/g, function (c) {
return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];});
}

function render() {
const root = document.getElementById('characters-module');
if (!root) return;
const result = load();
const save = result.save;
const active = save.activeId ? characters.find(function (c) {
return c.id === save.activeId;
}) : null;
const progress = active ? save.collection[active.id] : null;

root.innerHTML =
  '<section class="box panel">' +
  '<h2>Mes personnages</h2>' +
  '<p>100 emplacements : 50 classiques et 50 nocturnes.</p>' +
  '<p class="note">Les fiches provisoires seront remplacées lorsque les noms officiels seront confirmés.</p>' +
  (active && progress
    ? '<div class="p"><h3>' + escapeHtml(active.name) + '</h3>' +
      '<p>Monde : ' + escapeHtml(active.world) + ' · Niveau ' + progress.level + '/50</p>' +
      '<p>Élément : ' + escapeHtml(active.element) + ' · Arme : ' + escapeHtml(active.weapon) + '</p>' +
      '<p>Expérience : ' + progress.xp + ' / ' + xpForNext(progress.level) + '</p>' +
      '<p>Force ' + progress.stats.force + ' · Défense ' + progress.stats.defense +
      ' · Agilité ' + progress.stats.agility + ' · Magie ' + progress.stats.magic + '</p></div>'
    : '<p>Aucun personnage sélectionné pour ce compte.</p>') +
  '<h3>Choisir un personnage</h3>' +
  '<label for="gl-character-world">Monde</label>' +
  '<select id="gl-character-world"><option value="classique">Monde classique</option><option value="nuit">Monde nocturne</option></select>' +  '<label for="gl-character-select">Personnage</label>' +
  '<select id="gl-character-select">' +
  characters.filter(function (c) { return c.world === 'classique'; }).map(function (c) {
    return '<option value="' + c.id + '">' + escapeHtml(c.name) +
      (c.provisional ? ' (provisoire)' : '') + '</option>';
  }).join('') + '</select>' +
  '<button class="btn" id="gl-character-choose">Choisir / reprendre</button>' +
  '<button class="btn v" id="gl-character-xp">Gagner 50 XP (test)</button>' +
    '<h3>Ma collection</h3>' +
  '<div class="chips">' + Object.keys(save.collection).map(function (id) {
    const c = characters.find(function (item) { return item.id === id; });
    return c ? '<span>' + escapeHtml(c.name) + ' · Niv. ' +
      save.collection[id].level + '</span>' : '';
  }).join('') + '</div>' +
  '<p class="note">Sauvegarde actuelle : navigateur seulement. La synchronisation Supabase reste à mettre en place.</p>' +
  '</section>';

const worldSelect = document.getElementById('gl-character-world');
const characterSelect = document.getElementById('gl-character-select');
  worldSelect.addEventListener('change', function () {
  characterSelect.innerHTML = characters.filter(function (c) {
    return c.world === worldSelect.value;
  }).map(function (c) {
    return '<option value="' + c.id + '">' + escapeHtml(c.name) +
      (c.provisional ? ' (provisoire)' : '') + '</option>';
  }).join('');
});
document.getElementById('gl-character-choose').addEventListener('click', function () {
  try { choose(characterSelect.value); render(); }
  catch (error) { alert(error.message); }
});
document.getElementById('gl-character-xp').addEventListener('click', function () {
  try { awardXp(50); render(); }
  catch (error) { alert(error.message); }
});

}

window.GreenLeafCharacters = {
list: function () { return characters.slice(); },
getSave: function () { return load().save; },
choose: choose,
awardXp: awardXp,
render: render,
maxLevel: MAX_LEVEL
};

const menu = document.getElementById('menu');
if (menu && !document.getElementById('greenleaf-characters-menu')) {
const button = document.createElement('button');
button.id = 'greenleaf-characters-menu';
button.dataset.go = 'personnages';
button.innerHTML = '🧙Mes personnages';
menu.appendChild(button);
}

if (typeof window.VW !== 'undefined') {
window.VW.personnages = render;
}

document.addEventListener('DOMContentLoaded', render);
})();
