# État des fonctions — World 3.1 (19/10/2026)

| Domaine | État | Notes |
|---|---|---|
| Interface (accueil, navigation, boutons de l'image de référence) | Démo locale | 9 onglets, 16 entrées de menu, raccourcis |
| Carte des Royaumes (`carte/index.html`) | Visuelle + interactive | 10 royaumes, 7 portraits, 5 montures ; pas de sauvegarde serveur |
| Catalogue | Démo | 2 références « À confirmer » ; prix calculés (30 % nets) |
| Calculateur (`outils/`) | Fonctionnel en local | Trajet réparti, objectif net, grille de livraison, 30 km |
| Paniers classique / nocturne | Démo, mémoire du navigateur | Perdus au rechargement de la page |
| Commandes, codes de remise, journal d'audit | Simulation | Codes aléatoires locaux, aucune valeur de sécurité |
| Producteurs, commission 3 % | Présentation | Conditions affichées ; pas de profils, pas de paiement |
| Accès Monde de la Nuit | Verrou local de démonstration | **Pas de sécurité réelle** |
| Supabase / Netlify | Non connecté | N'écrase pas la version 5.3 |
| Authentification, paiements, portefeuille | Non connecté | Étapes 8 et 9 du cahier |
