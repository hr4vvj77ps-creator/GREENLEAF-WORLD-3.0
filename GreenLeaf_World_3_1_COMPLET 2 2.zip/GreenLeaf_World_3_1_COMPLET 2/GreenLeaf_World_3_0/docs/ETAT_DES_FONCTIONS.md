# État des fonctions dans le ZIP

| Domaine | État | Notes |
|---|---|---|
| Interface GreenLeaf World 3.0 | Démo locale | Navigation entre sections |
| Carte fantastique | Visuelle | Pas de sauvegarde serveur |
| Catalogues et règles de marge | Exemples / règles | Prix non confirmés clairement signalés |
| Producteurs et réseau | Présentation | Pas de profils connectés |
| Paniers classique/nocturne | Local navigateur pendant la session | Pas de commandes réelles |
| Accès Monde de la Nuit | Verrouillage local de démonstration | Pas sécurisé côté serveur |
| Livraison et codes | Simulation visuelle | Aucun code réel |
| Paiements bancaires | Non connecté | Aucun prestataire configuré |
| Crypto et QR de paiement | Cahier des charges uniquement | Aucun portefeuille, conversion ou paiement |
| Supabase / Netlify | Non connecté dans ce ZIP | N’écrase pas la version 5.3 |
| Authentification réelle | Non connecté dans ce ZIP | Pas de compte réel |

Ce tableau est volontairement explicite pour éviter toute confusion entre concept, prototype et fonction réellement opérationnelle.
