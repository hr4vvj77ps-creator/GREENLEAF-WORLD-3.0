# GreenLeaf World 3.2 — plan d’intégration

## Décisions
- Référence visuelle : `GreenLeaf_World_3_2/assets/interface-reference-user.jpeg`. Deux concepts illustrés supplémentaires sont fournis dans `assets/`.
- GreenLeaf 5.3 Auth PIN est conservé séparément et l’archive originale est incluse sans modification.
- Monde de la Nuit : invisible dans le menu classique ; accès réel uniquement après autorisation individuelle validée côté serveur. L’accès « Autoriser en démo » ne fonctionne que localement.
- Face ID/Touch ID : reporté, non activé.

## Fonctions à développer puis tester
1. Connexion World 3.2 via l’authentification déjà en service, en conservant pseudo/PIN et e-mail/mot de passe.
2. Profil de rôle obtenu depuis une source serveur fiable, jamais depuis une variable JavaScript modifiable.
3. Politiques RLS et stockage privé pour les données du Monde de la Nuit ; aucune fuite par recherche, API, URL, fichier ou endpoint.
4. Données persistantes de personnages, équipement (épées, bâtons de fée, armures, grimoires, potions, matériaux), montures, familiers, quêtes, cartes et fragments de trésor.
5. Paniers et historiques séparés entre les univers.
6. Commandes, stock, remise de colis et retrait client avec événements idempotents et journal d’audit. Distance maximale de conception : 30 km à l’aller entre client et point de rendez-vous.
7. Paiements réels seulement après sélection d’un prestataire, validation juridique et tests de bout en bout. Le QR est une demande de paiement, jamais une preuve de paiement.

## Ne pas confondre
Un écran visuel n’implique pas que sa fonction serveur existe. Cette compilation ne prétend pas que les paiements, la connexion du prototype, les données de jeu ou les livraisons sont déjà intégrés.
