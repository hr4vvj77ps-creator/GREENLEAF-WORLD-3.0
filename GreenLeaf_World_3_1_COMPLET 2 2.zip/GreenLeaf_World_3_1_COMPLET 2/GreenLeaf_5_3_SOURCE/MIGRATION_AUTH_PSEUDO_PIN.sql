-- GreenLeaf 5.3 — profils, rôles et limitation des tentatives PIN
-- À exécuter dans Supabase > SQL Editor avec le rôle postgres.
-- Ne met AUCUN PIN en base. Les tentatives sont suivies côté serveur.

create schema if not exists private;

create table if not exists public.gl_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  role text not null default 'client' check (role in ('client','livreur','moderateur','admin')),
  approved boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.gl_profiles enable row level security;
drop policy if exists "Users read own profile" on public.gl_profiles;
create policy "Users read own profile" on public.gl_profiles
  for select to authenticated using (user_id = (select auth.uid()) or private.is_admin());
drop policy if exists "Admins manage profiles" on public.gl_profiles;
create policy "Admins manage profiles" on public.gl_profiles
  for all to authenticated using (private.is_admin()) with check (private.is_admin());
grant select on public.gl_profiles to authenticated;
grant insert, update, delete on public.gl_profiles to authenticated;

create table if not exists public.gl_pin_attempts (
  attempt_key text primary key,
  failed_count integer not null default 0,
  blocked_until timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.gl_pin_attempts enable row level security;
revoke all on public.gl_pin_attempts from public, anon, authenticated;

-- Assure que les nouveaux profils n'obtiennent jamais automatiquement un rôle admin.
create or replace function private.gl_new_profile_defaults()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.role = 'admin' then new.role := 'client'; end if;
  new.approved := false;
  return new;
end; $$;
revoke all on function private.gl_new_profile_defaults() from public, anon, authenticated;

-- Le compte administrateur existant doit conserver son rôle dans private.user_roles.
-- Vérifier que private.is_admin() existe déjà et que l'UUID admin actuel y est enregistré.
