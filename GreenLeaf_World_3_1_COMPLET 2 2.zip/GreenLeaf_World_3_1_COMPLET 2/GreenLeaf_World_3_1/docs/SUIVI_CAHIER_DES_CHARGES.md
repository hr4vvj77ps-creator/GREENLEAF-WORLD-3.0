# Suivi du cahier des charges — GreenLeaf World 3.0
Mise à jour : 19 octobre 2026

## Décisions du porteur de projet (à reporter dans le cahier)
1. **Objectif de rentabilité** : 30 % nets une fois la commande récupérée ET livrée (trajet d’approvisionnement + livraison compris). Base de calcul par défaut : les recettes (le calculateur permet aussi « sur les coûts »).
2. **Prix supérieurs au repère France** : conservés (choix assumé, c’est un service de commande et de livraison). Ils sont signalés, jamais bloqués. Cela complète la règle « comparer au marché français » du cahier.
3. **Commission de 3 %** sur les transactions des prestataires de services (producteurs, mécaniciens, couturiers, cordonniers, magasins…) : affichée avant acceptation, conformément au principe « pas de commission implicite ».
4. **Tabac / alcool** : non intégrés. Catégories réglementées désactivées tant que la conformité n’est pas validée (le tabac rapporté d’Espagne ne peut pas être revendu : monopole).

## État par étape de livraison
| # | Étape | État |
|---|---|---|
| 1-2 | Audit du dépôt, inventaire | Fait en lecture du ZIP ; aucune écriture sur 5.3 |
| 3 | Schéma de données et permissions (Supabase/RLS) | **À faire** (aucun accès au projet Supabase) |
| 4 | Catalogue et calculs | Démo : 2 références « À confirmer », calculateur corrigé, remises par palier |
| 5 | Paniers, messagerie, commandes | Démo locale : paniers classique/nocturne séparés, message + panier joint, commandes simulées |
| 6 | Producteurs, réseau, livraison | Démo locale : règle 30 km, deux codes distincts, journal d’audit, conditions de commission |
| 7 | Monde de la Nuit, séparation des données | Verrou **local de démonstration** uniquement |
| 8 | Authentification et sécurité | **À faire** |
| 9 | Paiements, portefeuille/cagnotte | **Bloqué** : prestataire agréé + validation juridique |
| 10 | Tests, staging, déploiement | **À faire** |

## Points de vigilance mesurés
- Les remises alimentation (−5 / −10 / −15 / −20 %) font passer le net sous 30 % : panier de 8 thons, livraison à 10 km, net ≈ 15,9 %. Il faut décider : remises financées par la marge, ou paliers revus.
- Livraison : pour tenir 30 %, frais minimum = coût de livraison ÷ 0,70 (≈ 14,29 € à 10 km), contre 4–7 € dans la grille actuelle.
- Prix d’achat (thon 7,70 € le 11/09/2026 ; bonito 8,10 € le 15/10/2026) : prix de détail en ligne, pas des tarifs professionnels ; produits « À confirmer ».
- Cagnotte en euros = monnaie électronique ; points de jeu à garder séparés de l’argent, sans conversion automatique.
