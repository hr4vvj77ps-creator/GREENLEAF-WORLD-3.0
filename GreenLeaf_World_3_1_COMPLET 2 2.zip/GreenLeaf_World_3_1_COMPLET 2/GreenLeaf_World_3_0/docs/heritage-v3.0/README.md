# GreenLeaf World 3.0 — prototype de conception

Cette archive est une **nouvelle maquette indépendante** pour regrouper les idées GreenLeaf World évoquées jusqu’ici : univers de jeu, monde classique et Monde de la Nuit, catalogues/prix, producteurs, réseau, commandes, livraisons et architecture de paiement.

## Lancer la maquette
1. Décompresser `GreenLeaf_World_3_0.zip`.
2. Ouvrir `index.html` dans un navigateur récent.
3. Naviguer avec le menu. Les actions sont locales et simulées.

Aucun serveur, Supabase, Netlify, compte réel, paiement bancaire, portefeuille crypto, GPS, QR de paiement ou transfert de fonds n’est connecté.

## Important : relation avec GreenLeaf 5.3
Cette archive **ne remplace pas** le dossier GreenLeaf 5.3 qui fonctionne déjà et ne modifie pas son contenu. Conserve les deux séparément. Avant d’intégrer quoi que ce soit à l’application existante, identifier la bonne version, vérifier les fichiers, faire une sauvegarde et tester en environnement séparé.

## Fonctions représentées
- Monde classique : carte stylisée, royaumes, refuge persistant prévu, quêtes, compagnons, montures et trésors.
- Monde de la Nuit : univers séparé et invisible dans la carte classique ; accès local de démonstration seulement. En production, l’autorisation doit être imposée côté serveur et dans les politiques Supabase/RLS.
- Catalogues : filtres, prix d’achat/vente, marge, €/kg et état « à confirmer » à renseigner avec des références réelles.
- Règles de marge mémorisées : cible de bénéfice GreenLeaf de 1,50 € pour petites quantités et 2,00 € pour plus grandes quantités lorsque les prix vérifiés le permettent. Ne pas inventer les prix ; afficher « à confirmer ».
- Promotions épicerie espagnole envisagées : panier de 50 € = -5 %, 80 € = -10 %, 120 € = -15 %, 230 € = -20 %. À valider juridiquement/commercialement et selon les produits éligibles.
- Parfums : parfums classiques à porter sur la peau ; cible discutée de 35–38 € si les références réelles le justifient, revente sous 50 €, lot de cinq avec remise de 20 % envisagée. Ce ne sont pas des prix vérifiés.
- Producteurs : profil, catalogue, stock, prix, commandes et domaine fantastique séparé ; liberté de vente directe, frais/commissions explicites.
- Paniers et historiques : séparation classique/nocturne prévue ; les paniers de cette maquette ne sont que locaux.
- Livraisons : suivi par colis, code de remise au relais distinct du code de retrait client, permissions par rôle et journal d’audit prévus. Limite de conception retenue : 30 km à l’aller entre chaque client et le point de rendez-vous.
- Finances : distinction ventes classiques, ventes directes et concept crypto nocturne. Aucun paiement n’est connecté.
- Progression : XP personnelle, réputation professionnelle et progression globale distinctes ; garde-fous contre faux comptes et parrainage artificiel.

## Concept crypto du Monde de la Nuit (pas implémenté)
- Prix vendeur exprimé en euros ; choix de l’actif/réseau côté vendeur et côté client.
- Conversion entre actifs uniquement si le prestataire, la liquidité, le taux et le réseau sont compatibles.
- Paiement envisagé à la livraison ; devis temporaire, frais visibles, QR unique à la commande et vérification indépendante de la transaction sur chaîne.
- Le QR ne prouve jamais le paiement. Ne jamais stocker de clé privée ou phrase secrète.
- USDC, EURC et USDT sont seulement des pistes à comparer. Actifs, réseaux, prestataire, disponibilité et conformité UE restent à vérifier.
- Avant tout paiement réel, obtenir une validation juridique/réglementaire (notamment MiCA et services de paiement), fiscale et sécurité. Un paiement direct au vendeur peut être étudié, sous réserve de validation du modèle.

## Règles de sécurité
- Ne jamais mettre une clé Supabase `service_role` ou autre secret dans un site public.
- Authentification, autorisations, commandes, prix et stocks doivent être validés côté serveur.
- Les boutons de cette maquette ne constituent pas un système de permissions.
- Pas de suivi GPS en continu par défaut ; tout partage de localisation réel doit être volontaire, minimal et sécurisé.
- Les points de jeu ne sont pas de l’argent et ne sont pas automatiquement échangeables.

## Prochaine étape recommandée
1. Vérifier et sauvegarder GreenLeaf 5.3.
2. Comparer les catalogues actuels et les données disponibles sans inventer de prix.
3. Définir l’architecture et les migrations Supabase après inspection.
4. Intégrer les fonctions progressivement et tester chaque rôle et chaque cas d’erreur.
5. N’activer aucun paiement réel avant validation juridique, technique et prestataire.
