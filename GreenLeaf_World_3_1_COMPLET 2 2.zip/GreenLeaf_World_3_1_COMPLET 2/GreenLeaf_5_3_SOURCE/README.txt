GreenLeaf 5.0 — mise à jour

Cette archive conserve le numéro de version de référence 5.0. Ce n’est pas une version 4.10 ou 4.11.

Inclus :
- Démo web locale : ouvrir index.html dans un navigateur récent.
- Panier de demande et messagerie de démonstration conservés.
- Images de catégories issues de la base de démonstration précédente.
- Tarifs déjà inscrits dans le fichier conservés, notamment les paliers fournis pour la résine CBD triple filtrée : 1 g = 9 €, 2,5 g = 20 €, 5,5 g = 40 €, 10 g = 70 €, 25 g = 170 €, 50 g = 320 €, 100 g = 500 €.
- Rubrique parfums consacrée aux parfums à porter (eau de toilette / eau de parfum), et non aux arômes de vapotage. Les prix et marques manquants sont signalés comme à confirmer plutôt que devinés.
- Les prix non retrouvés dans les fichiers restent à confirmer.

Limites : démo statique. La messagerie et le panier ne transmettent pas de données à un autre appareil. Vérifier les prix et la conformité réglementaire avant toute publication ou vente.


Images personnelles intégrées dans GreenLeaf 5.0 : Tazmania, Champignons, Love, Black & White, CBD Static et CBD 3x Filtre. Jaune Mousseux conserve le visuel de boisson existant dans la catégorie Nourriture & Boissons.

Nouvelle interface : sous-catégorie « Fantômes » avec cadenas et bouton œil pour afficher/masquer la prévisualisation.
Important : le verrouillage est uniquement visuel côté navigateur dans cette démo ; une vraie confidentialité exige une authentification et un serveur.


--- AJOUT CONNEXION GREENLEAF 5.3 ---
Voir README_AUTH_EMAIL_PIN_VISUALID.txt et exécuter MIGRATION_EMAIL_AUTH_PROFILE.sql pour les nouvelles inscriptions e-mail.
