# GreenLeaf World 3.1 — projet de travail

## Ouvrir
Double-cliquez sur `index.html` (aucun serveur requis). Pour un test plus proche d'un vrai site :
`python3 -m http.server 8000` dans ce dossier, puis http://localhost:8000

## Structure
- `index.html`, `styles.css`, `app.js` — interface principale (démo locale). Vues et logique métier dans `app.js` (objet `VW`, calculs `cartCalc`, constantes `RATE`, `T`, `TIERS`).
- `carte/index.html` — carte interactive des 10 royaumes (données dans le tableau `R`).
- `assets/ui/` — visuels de l'accueil (découpés de la référence) ; `assets/personnages/` — portraits et montures (découpés de `concept-univers-greenleaf.png`) ; `assets/references/` — image de référence et deux concepts d'origine, en pleine résolution.
- `outils/` — calculateur corrigé de prix/livraison ; module de contrôle des 30 km (`greenleaf-distance-rendez-vous.js`, version d'origine, non modifiée).
- `archives/` — anciennes versions, conservées pour mémoire.
- `docs/` — cahier des charges (d'origine), suivi d'avancement, état des fonctions.

## Règles de calcul en vigueur
- Trajet : 250 € répartis sur un budget d'achats de 3 500 € (7,14 % du coût d'achat).
- Prix = (achat + trajet) ÷ 0,70 pour 30 % nets sur les recettes. Prix au-dessus du repère France : conservés, signalés (décision assumée : service).
- Livraison : coût = km aller × 2 × 0,35 € + 3 € ; minimum facturé pour tenir 30 % = coût ÷ 0,70.
- Remises alimentation : 50 € −5 %, 80 € −10 %, 120 € −15 %, 230 € −20 % (elles font passer le net sous 30 % : à trancher).
- Limite : 30 km maximum à l'aller entre client et point de rendez-vous.

## Prochaines étapes (ordre du cahier des charges)
1. Étape 3 : schéma de données et règles d'accès (Supabase/RLS), séparation du Monde de la Nuit — préparer sans exécuter, après sauvegarde de la base 5.3.
2. Remplacer le catalogue démo par des références dont les prix d'achat professionnels sont confirmés.
3. Fusionner la carte dans l'interface (vue « Carte au trésor »).
4. Étape 8 : authentification pseudo/PIN existante + e-mail.
5. Étape 9 : paiements et cagnotte, seulement après choix d'un prestataire agréé et validation juridique.

## Limites connues
- Tout est en mémoire du navigateur ; rien n'est enregistré.
- Portraits de la carte : petits (découpes de concept), flous en grand format.
- Gardiens manquants : Grottes de cristal, Désert des dragons, Cité engloutie, Marais, Sept Mers (noms et classes = propositions).
- Les polices viennent de Google Fonts (connexion requise ; sinon polices de secours).
- Tabac et alcool volontairement absents (revente d'un produit rapporté d'Espagne : voir `docs/SUIVI_CAHIER_DES_CHARGES.md`).
