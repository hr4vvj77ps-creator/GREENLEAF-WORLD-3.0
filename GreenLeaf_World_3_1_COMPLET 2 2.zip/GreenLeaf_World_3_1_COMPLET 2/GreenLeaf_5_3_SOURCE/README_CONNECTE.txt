GreenLeaf 5.0 — branchement Supabase (première intégration)

1. Dans Supabase > SQL Editor, exécuter MIGRATION_SUPABASE.sql une seule fois.
2. Ouvrir index.html depuis un navigateur connecté à Internet (le SDK Supabase est chargé depuis jsDelivr).
3. Aller dans « Mon compte », créer un compte ou se connecter.
4. Le compte administrateur déjà créé doit utiliser son e-mail habituel. L'UUID admin déjà configuré doit conserver le rôle admin dans private.user_roles.
5. Pour autoriser un autre compte, copier son UUID depuis Authentication > Users, puis dans Mon compte > Autorisations Fantômes, le saisir et cliquer « Autoriser ». La fonction SQL vérifie côté serveur que l'appelant est admin.
6. Pour vérifier Fantômes, revenir à Boutique > Festif / Soirée animée > Fantômes et cliquer sur l'œil. Le statut est vérifié par la fonction serveur puis la table public.ghost_items est lue sous RLS.

Sécurité / limites :
- La clé sb_publishable est prévue pour le navigateur ; ne jamais mettre une clé service_role/secret dans ce fichier.
- La sécurité réelle dépend des politiques RLS et des permissions SQL Supabase, pas du verrouillage visuel.
- Le projet n'a pas été testé contre le serveur Supabase depuis cet environnement. Tester inscription, connexion, compte autorisé et compte refusé.
- L'historique de messagerie et le panier restent locaux au navigateur dans cette version.
- La démo est un prototype web statique, pas une application iOS native ni un APK.


Ajout GreenLeaf 5.3 : voir MIGRATION_FANTOMES_5_3.sql et README_FANTOMES_5_3.txt. Le SQL n'a pas encore été exécuté sur le projet Supabase réel.
