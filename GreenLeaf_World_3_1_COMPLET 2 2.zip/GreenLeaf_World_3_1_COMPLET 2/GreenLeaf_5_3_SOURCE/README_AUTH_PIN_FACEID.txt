GREENLEAF 5.3 — COMPTE PSEUDO + PIN (PACK DE MISE EN PLACE)

CONTENU
- index.html : formulaire pseudo + PIN branché sur la fonction Supabase.
- MIGRATION_AUTH_PSEUDO_PIN.sql : profils, rôles, approbation et table privée de limitation des essais.
- supabase/functions/greenleaf-pin-auth/index.ts : création de compte / connexion côté serveur.

IMPORTANT — CE QUI EST ET N'EST PAS ACTIVÉ
- Le formulaire pseudo + PIN appelle une Edge Function. Il ne fonctionnera qu'après déploiement de la fonction, configuration des secrets et exécution du SQL.
- Les comptes créés sont en attente (approved=false). Il faut un outil d'administration pour autoriser les comptes et leur rôle.
- Le bouton Face ID/empreinte est volontairement informatif : la biométrie n'est PAS encore activée. Il faut ajouter une vraie implémentation WebAuthn/passkeys côté serveur, enregistrer et vérifier les challenges/credentials, puis associer la passkey au compte. Ne pas annoncer Face ID comme opérationnel avant les tests.
- Le PIN 6 chiffres est moins robuste qu'un mot de passe long ou une passkey. Les limites d'essais incluses dans cette version sont par pseudo ; ajoute aussi un rate limit IP/WAF et une politique de récupération de compte avant production.
- Les images Fantômes dans le dossier Netlify restent publiques. Pour confidentialité réelle, déplacer les images dans un bucket Supabase Storage privé et servir des URL signées seulement après vérification d'autorisation. Les règles RLS sur ghost_items ne protègent pas les fichiers publics.
- Ne jamais mettre SUPABASE_SERVICE_ROLE_KEY ou GREENLEAF_PIN_PEPPER dans index.html, Netlify public, ou un dépôt public. Les secrets vont uniquement dans Supabase Edge Function secrets.

ÉTAPES
1) Sauvegarde le site actuel.
2) Dans Supabase > SQL Editor, vérifie que private.is_admin(), private.user_roles, private.ghost_access, public.admin_set_ghost_access() et public.can_current_user_access_ghosts() existent déjà. Exécute MIGRATION_AUTH_PSEUDO_PIN.sql seulement si ces prérequis sont en place.
3) Depuis un terminal avec Supabase CLI et le dossier du projet, déploie : supabase functions deploy greenleaf-pin-auth
4) Configure les secrets de fonction dans Supabase (Dashboard > Edge Functions > Secrets) : GREENLEAF_PIN_PEPPER avec une valeur aléatoire secrète d'au moins 32 caractères. SUPABASE_URL, SUPABASE_ANON_KEY et SUPABASE_SERVICE_ROLE_KEY sont normalement injectés automatiquement par Supabase; vérifie leur présence. Ne copie jamais le service role dans le site.
5) Déploie le dossier du site sur Netlify.
6) Teste la création d'un pseudo, la connexion, 5 PIN erronés, la déconnexion et l'accès Fantômes avec un compte non autorisé.
7) Pour autoriser un compte, l'admin doit modifier gl_profiles.approved et attribuer le rôle approprié depuis une interface admin sécurisée ou SQL. Le rôle admin ne doit jamais être assignable par inscription publique.

NOTE DE SÉCURITÉ
Le code fourni est un socle d'intégration, pas une preuve de déploiement ni un audit de sécurité. Ne l'utilise pas pour des données sensibles avant tests réels et verrouillage des politiques RLS/Storage.
