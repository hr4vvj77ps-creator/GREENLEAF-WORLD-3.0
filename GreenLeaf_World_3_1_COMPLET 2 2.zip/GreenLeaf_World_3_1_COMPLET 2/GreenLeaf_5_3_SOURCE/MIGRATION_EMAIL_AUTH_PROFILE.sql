-- GreenLeaf 5.3 — création automatique du profil e-mail
-- Ne modifie pas les profils ni les rôles existants.
-- Ignore les comptes techniques utilisés par la connexion PIN.

create or replace function public.gl_handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  candidate text;
begin
  -- Ne pas créer de doublon pour les comptes techniques du PIN.
  if coalesce(new.email, '') ilike '%@accounts.greenleaf.invalid'
     or coalesce(new.raw_user_meta_data ->> 'account_type', '') = 'greenleaf_admin' then
    return new;
  end if;

  candidate := coalesce(new.raw_user_meta_data ->> 'username', '');

  if candidate !~ '^[A-Za-z0-9_.-]{3,24}$' then
    candidate := 'gl_' || substr(replace(new.id::text, '-', ''), 1, 12);
  end if;

  if exists (
    select 1
    from public.gl_profiles p
    where lower(p.username) = lower(candidate)
  ) then
    candidate := 'gl_' || substr(replace(new.id::text, '-', ''), 1, 12);
  end if;

  insert into public.gl_profiles (user_id, username, role, approved)
  values (new.id, candidate, 'client', false)
  on conflict (user_id) do nothing;

  return new;
end;
$$;

revoke all on function public.gl_handle_new_auth_user()
from public, anon, authenticated;

drop trigger if exists on_auth_user_created_greenleaf_profile
on auth.users;

create trigger on_auth_user_created_greenleaf_profile
after insert on auth.users
for each row
execute function public.gl_handle_new_auth_user();
