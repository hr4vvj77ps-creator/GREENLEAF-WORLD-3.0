GREENLEAF 5.3 — correctif d’affichage Fantômes

Correctif de l’interface :
- Les tuiles Tazmania, Love, Black & White, Ski et Champignons sont masquées par défaut.
- L’ouverture du panneau attend une réponse positive de Supabase via can_current_user_access_ghosts.
- En cas de déconnexion ou de changement de session, le panneau et les tuiles sont masqués.

Installation :
1. Décompresse cette archive.
2. Déploie le contenu du dossier GreenLeaf_5_3 sur Netlify.
3. Teste d’abord déconnecté, puis avec un compte connecté mais non autorisé, puis avec un compte autorisé.

Limite importante :
Ce correctif protège l’affichage normal dans l’interface. Il ne suffit pas à rendre des noms ou images intégrés dans des fichiers publics confidentiels : le HTML et les fichiers statiques restent inspectables. Pour une confidentialité réelle des images, il faut les placer dans un bucket Supabase Storage privé et générer des URL temporaires après autorisation. Les données doivent rester protégées par RLS côté Supabase.
Le correctif n’a pas été exécuté contre le projet Supabase réel.
